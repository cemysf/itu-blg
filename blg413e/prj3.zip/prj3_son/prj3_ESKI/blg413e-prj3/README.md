# blg413e-prj3

compile:
```
make
```

load:
```
insmod ./range.ko
```

unload:
```
rmmod range
```

control:
```
lsmod
```
```
dmesg|tail
```

